Given('user go to web') do
  pending # Write code here that turns the phrase above into concrete actions
end

Given('user click OK') do
  pending # Write code here that turns the phrase above into concrete actions
end