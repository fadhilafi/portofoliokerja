def Landing_Page()
    $driver.navigate.to "https://mkk3.dcidev.id/mandiri"
end    