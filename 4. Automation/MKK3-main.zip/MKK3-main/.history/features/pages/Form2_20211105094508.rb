def Company_Name()
    $driver.find_element(:xpath, '//div[@class="wizard-navigation"]/div[2]/div[2]/div/fieldset[1]/div/input').send_keys("Wanokuni")
    sleep(2)
    $driver.hide_keyboard
    sleep(2)
end  

def Code_Area()
    $driver.find_element(:xpath, '//div[@class="wizard-navigation"]/div[2]/div[2]/div/fieldset[2]/div/div/div[1]/input').send_keys("0274")
    sleep(2)
    $driver.hide_keyboard
    sleep(2)
end    

def Company_Phone()
    $driver.find_element(:xpath, '//div[@class="wizard-navigation"]/div[2]/div[2]/div/fieldset[2]/div/div/div[2]/input').send_keys("242424")
    sleep(2)
    $driver.hide_keyboard
    sleep(2)
end    

def Bussiness_Type()
    $driver.find_element(:xpath, '//div[@class="wizard-navigation"]/div[2]/div[2]/div/fieldset[3]/div/input').send_keys("Tambang")
    sleep(2)
    $driver.hide_keyboard
    sleep(2)
end    

def Position_Status()
    $driver.find_element(:xpath, '//div[@class="wizard-navigation"]/div[2]/div[2]/div/fieldset[4]/div/input').send_keys("Pemilik")
    sleep(2)
    $driver.hide_keyboard
    sleep(2)
end    

def Permanent_Employee()
    $driver.find_element(:xpath, '//div[@class="wizard-navigation"]/div[2]/div[2]/div/fieldset[5]/div/div/div[1]/label').click
    sleep(2)
end    

def Temporary_Employee()
    $driver.find_element(:xpath, '//div[@class="wizard-navigation"]/div[2]/div[2]/div/fieldset[5]/div/div/div[2]/label').click
    sleep(2)
end    

def Working_Since()
    $driver.find_element(:xpath, '//div[@class="wizard-navigation"]/div[2]/div[2]/div/fieldset[6]/div/div').click
    sleep(2)
    $driver.find_element(:xpath, '//div[@class="wizard-navigation"]/div[2]/div[2]/div/fieldset[6]/div/div/div[2]/header/span[1]').click
    sleep(2)
    $driver.find_element(:xpath, '//div[@class="wizard-navigation"]/div[2]/div[2]/div/fieldset[6]/div/div/div[4]/span[4]').click
    sleep(2)
    $driver.find_element(:xpath, '//div[@class="wizard-navigation"]/div[2]/div[2]/div/fieldset[6]/div/div/div[3]/span[5]').click
    sleep(2)
    $driver.find_element(:xpath, '//div[@class="wizard-navigation"]/div[2]/div[2]/div/fieldset[6]/div/div/div[2]/div/span[13]').click
    sleep(2)
end    

def Code_Area()
    $driver.find_element(:xpath, '//div[@class="wizard-navigation"]/div[2]/div[2]/div/fieldset[2]/div/div/div[1]/input').send_keys("0274")
    sleep(2)
    $driver.hide_keyboard
    sleep(2)
end    

def Code_Area()
    $driver.find_element(:xpath, '//div[@class="wizard-navigation"]/div[2]/div[2]/div/fieldset[2]/div/div/div[1]/input').send_keys("0274")
    sleep(2)
    $driver.hide_keyboard
    sleep(2)
end    

def Code_Area()
    $driver.find_element(:xpath, '//div[@class="wizard-navigation"]/div[2]/div[2]/div/fieldset[2]/div/div/div[1]/input').send_keys("0274")
    sleep(2)
    $driver.hide_keyboard
    sleep(2)
end    

def Code_Area()
    $driver.find_element(:xpath, '//div[@class="wizard-navigation"]/div[2]/div[2]/div/fieldset[2]/div/div/div[1]/input').send_keys("0274")
    sleep(2)
    $driver.hide_keyboard
    sleep(2)
end    

def Code_Area()
    $driver.find_element(:xpath, '//div[@class="wizard-navigation"]/div[2]/div[2]/div/fieldset[2]/div/div/div[1]/input').send_keys("0274")
    sleep(2)
    $driver.hide_keyboard
    sleep(2)
end    

def Code_Area()
    $driver.find_element(:xpath, '//div[@class="wizard-navigation"]/div[2]/div[2]/div/fieldset[2]/div/div/div[1]/input').send_keys("0274")
    sleep(2)
    $driver.hide_keyboard
    sleep(2)
end    

def Code_Area()
    $driver.find_element(:xpath, '//div[@class="wizard-navigation"]/div[2]/div[2]/div/fieldset[2]/div/div/div[1]/input').send_keys("0274")
    sleep(2)
    $driver.hide_keyboard
    sleep(2)
end    