<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Verify Operations</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>5</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>437cc529-6e28-4c94-ae29-e1709755d800</testSuiteGuid>
   <testCaseLink>
      <guid>665d328f-aff4-4e66-83d3-858388a521f0</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/operations/Verify Divide</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>ce29e1c6-e375-4907-89e0-02bb907017d6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/operations/Verify Minus</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>bc94eccf-0089-4a03-a65b-8662d83d3447</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/operations/Verify Multiply</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>bb746f7d-e860-43c0-88c1-d21e6bba82a6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/operations/Verify Plus</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
