class GenerateRandom {
    static number() {
        return Math.floor(Math.random() * 900) + 100;
    }
}

module.exports = GenerateRandom;
